// script.js
(function(){
  const $ = id => document.getElementById(id);
  const terminal = $('terminal');
  const inputArea = $('inputArea');
  const status = $('status');
  const resultArea = $('resultArea');

  document.getElementById('buildBtn').addEventListener('click', buildTables);
  document.getElementById('fillExample').addEventListener('click', fillExample);
  document.getElementById('resetBtn').addEventListener('click', resetAll);
  document.getElementById('solveBtn').addEventListener('click', onSolve);
  document.getElementById('showMatrixBtn').addEventListener('click', showMatrix);
  document.getElementById('downloadCSV').addEventListener('click', downloadCSV);

  let state = { n:3, m:3, ingredientNames:[], productNames:[], compMatrix: [], stock: [] };

  function log(txt){
    terminal.innerText += txt + '\n';
    terminal.scrollTop = terminal.scrollHeight;
  }
  function clearTerminal(){ terminal.innerText = ''; }

  function buildTables(){
    const n = parseInt($('nProducts').value) || 0;
    const m = parseInt($('nIngredients').value) || 0;
    const ingRaw = $('ingredientNames').value.trim();
    const ingNames = ingRaw ? ingRaw.split(',').map(s=>s.trim()) : [];

    state.n = n; state.m = m; state.ingredientNames = ingNames.slice(0,m);

    // build HTML table: one row per product with columns for each ingredient
    let html = '<div class="card"><h3>Daftar Produk & Komposisi (per 1 martabak)</h3>';
    html += '<table><thead><tr><th>Produk</th>';
    for(let j=0;j<m;j++){
      const b = state.ingredientNames[j] || ('Bahan '+(j+1));
      html += `<th>${b}</th>`;
    }
    html += '</tr></thead><tbody>';
    for(let i=0;i<n;i++){
      html += '<tr>';
      html += `<td><input class="pname" data-i="${i}" type="text" value="Martabak ${i+1}"></td>`;
      for(let j=0;j<m;j++){
        html += `<td><input class="comp" data-i="${i}" data-j="${j}" type="number" min="0" step="any" value="0"></td>`;
      }
      html += '</tr>';
    }
    html += '</tbody></table>';

    // stok row
    html += '<h3 style="margin-top:12px">Stok Gudang</h3><table><thead><tr>';
    for(let j=0;j<m;j++){
      const b = state.ingredientNames[j] || ('Bahan '+(j+1));
      html += `<th>${b}</th>`;
    }
    html += '</tr></thead><tbody><tr>';
    for(let j=0;j<m;j++){
      html += `<td><input id="stok_${j}" type="number" min="0" step="any" value="0"></td>`;
    }
    html += '</tr></tbody></table></div>';

    inputArea.innerHTML = html;
    $('actions').style.display = 'block';

    clearTerminal();
    log('Form input dibuat. Isi komposisi & stok, lalu klik "Jalankan OBE & Hitung".');
    status.innerText = 'Siap input';
  }

  function fillExample(){
    buildTables();
    // sample names
    document.querySelectorAll('.pname').forEach((el, idx)=> el.value = ['Martabak Manis','Martabak Telur','Martabak Mini'][idx] || `Martabak ${idx+1}`);
    // sample comps (m must be >=3 ideally)
    const sample = [
      [300, 100, 2],  // Martabak Manis: Tepung(g), Gula(g), Telur(butir)
      [250, 50, 3],   // Martabak Telur
      [100, 30, 1]    // Martabak Mini
    ];
    document.querySelectorAll('.comp').forEach(el=>{
      const i = parseInt(el.dataset.i), j = parseInt(el.dataset.j);
      const v = (sample[i] && sample[i][j] !== undefined) ? sample[i][j] : 0;
      el.value = v;
    });
    // sample stocks
    const defaults = [2000, 800, 20];
    for(let j=0;j<state.m;j++){
      const s = $(`stok_${j}`);
      if (s) s.value = defaults[j] || 0;
    }
    clearTerminal();
    log('Contoh terisi. Periksa lalu jalankan OBE.');
    status.innerText = 'Contoh terisi';
  }

  function resetAll(){
    inputArea.innerHTML = '';
    $('actions').style.display = 'none';
    clearTerminal();
    resultArea.innerText = 'Belum ada hasil.';
    status.innerText = 'Reset';
  }

  function buildStateFromDOM(){
    // product names
    state.productNames = Array.from(document.querySelectorAll('.pname')).map(x=>x.value || 'Produk');
    // build compMatrix rows = bahan (m) cols = produk (n)
    const n = state.n, m = state.m;
    const compRowsByProduct = Array.from({length:n}, ()=>Array(m).fill(0));
    document.querySelectorAll('.comp').forEach(el=>{
      const i = parseInt(el.dataset.i), j = parseInt(el.dataset.j);
      compRowsByProduct[i][j] = parseFloat(el.value) || 0;
    });
    // transpose
    const compMatrix = Array.from({length:m}, (_,r)=> Array.from({length:n}, (_,c)=> compRowsByProduct[c][r] ));
    state.compMatrix = compMatrix;
    state.stock = [];
    for(let j=0;j<m;j++){
      const v = parseFloat($(`stok_${j}`).value) || 0;
      state.stock.push(v);
    }
  }

  function showMatrix(){
    try{ buildStateFromDOM(); } catch(e){ alert('Buat form dulu.'); return; }
    clearTerminal();
    log('Matriks A (koefisien) — baris=bahan, kolom=produk:');
    printMatrix(state.compMatrix);
    log('\nVektor stok B:');
    state.stock.forEach(v=> log(formatNum(v)));
  }

  function formatNum(x){
    if (Math.abs(x - Math.round(x)) < 1e-9) return String(Math.round(x));
    return Number(x).toFixed(6);
  }

  function printMatrix(mat){
    for(let i=0;i<mat.length;i++){
      const row = mat[i].map(v=> formatNum(v)).join('\t');
      log(row);
    }
  }

  // Gauss-Jordan with step logging (requires square system m == n)
  function onSolve(){
    try{ buildStateFromDOM(); } catch(e){ alert('Buat form dulu.'); return; }
    clearTerminal();
    status.innerText = 'Menjalankan OBE...';
    const m = state.m, n = state.n;
    if (m !== n){
      status.innerHTML = 'ERROR: aplikasi saat ini memerlukan m = n (bahan = produk). m=' + m + ' n=' + n;
      log('Sistem bukan kuadrat (m != n). Untuk dukungan over/under-determined minta fitur tambahan.');
      return;
    }

    // Build augmented matrix (deep copy)
    let mat = state.compMatrix.map((r,i)=> r.map(c=> Number(c)));
    for(let i=0;i<m;i++) mat[i].push(Number(state.stock[i] || 0));

    log('Matriks Augmented Awal [A | B]:');
    printAugmented(mat);

    const EPS = 1e-12;

    // Gauss-Jordan eliminasi
    for(let col=0; col<n; col++){
      // pivot selection (partial pivot)
      let pivotRow = col;
      let maxVal = Math.abs(mat[col][col]);
      for(let r=col+1; r<n; r++){
        const v = Math.abs(mat[r][col]);
        if (v > maxVal){ maxVal = v; pivotRow = r; }
      }
      if (Math.abs(mat[pivotRow][col]) < EPS){
        log(`Pivot ~ 0 di kolom ${col}. Sistem mungkin singular / tak unik.`);
        status.innerHTML = '<span style="color:#ff9b9b">Pivot nol — sistem singular / tidak unik</span>';
        break;
      }
      // swap if needed
      if (pivotRow !== col){
        [mat[col], mat[pivotRow]] = [mat[pivotRow], mat[col]];
        log(`Swap: R${col+1} <-> R${pivotRow+1}`);
        printAugmented(mat);
      }
      // normalize pivot row
      const pivot = mat[col][col];
      if (Math.abs(pivot - 1) > EPS){
        for(let k=col; k<=n; k++) mat[col][k] = mat[col][k] / pivot;
        log(`Normalize: R${col+1} <- R${col+1} / ${formatNum(pivot)}`);
        printAugmented(mat);
      }
      // eliminate other rows
      for(let r=0; r<n; r++){
        if (r === col) continue;
        const factor = mat[r][col];
        if (Math.abs(factor) < EPS) continue;
        for(let k=col; k<=n; k++){
          mat[r][k] = mat[r][k] - factor * mat[col][k];
        }
        log(`R${r+1} <- R${r+1} - (${formatNum(factor)}) * R${col+1}`);
        printAugmented(mat);
      }
    }

    // check if reduced to identity
    let solvable = true;
    for(let i=0;i<n;i++){
      for(let j=0;j<n;j++){
        if (i===j){
          if (Math.abs(mat[i][j] - 1) > 1e-6) solvable = false;
        } else {
          if (Math.abs(mat[i][j]) > 1e-6) solvable = false;
        }
      }
    }

    if (!solvable){
      log('\n[PERINGATAN] Matriks tidak tereduksi menjadi identitas. Sistem mungkin tidak memiliki solusi unik.');
      status.innerHTML = '<span style="color:#ff9b9b">Tidak ada solusi unik</span>';
      resultArea.innerText = 'Tidak ada solusi unik (periksa input).';
      return;
    }

    // extract solution (last column)
    const sol = mat.map(r => r[n]);
    log('\n=== Solusi (jumlah tiap jenis martabak) ===');
    let negative = false;
    let out = '';
    for(let i=0;i<n;i++){
      log(`x${i+1} (${state.productNames[i] || ('Martabak '+(i+1))}) = ${formatNum(sol[i])}`);
      out += `${state.productNames[i] || ('Martabak '+(i+1))}: ${formatNum(sol[i])}\n`;
      if (sol[i] < -1e-9) negative = true;
    }

    if (negative){
      status.innerHTML = '<span style="color:#ff9b9b">Solusi mengandung nilai negatif — periksa komposisi/stok</span>';
      resultArea.innerText = 'Solusi mengandung nilai negatif. Periksa input.';
    } else {
      status.innerHTML = 'Sukses: solusi valid';
      resultArea.innerText = out;
    }
  }

  function printAugmented(mat){
    for(let i=0;i<mat.length;i++){
      const row = mat[i].slice(0, mat[i].length-1).map(v=> formatNum(v)).join('  ');
      const b = formatNum(mat[i][mat[i].length-1]);
      log(`[ ${row} | ${b} ]`);
    }
  }

  function downloadCSV(){
    try{ buildStateFromDOM(); } catch(e){ alert('Buat form dulu.'); return; }
    const n = state.n, m = state.m;
    const headers = ['Produk'].concat(state.ingredientNames);
    let csv = headers.join(',') + '\n';
    for(let i=0;i<n;i++){
      const name = state.productNames[i] || ('Martabak '+(i+1));
      const comps = [];
      for(let j=0;j<m;j++) comps.push(state.compMatrix[j][i] || 0);
      csv += [name].concat(comps).join(',') + '\n';
    }
    csv += 'STOK,' + state.stock.join(',') + '\n';
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'input_martabak.csv';
    a.click(); URL.revokeObjectURL(url);
  }

})();
